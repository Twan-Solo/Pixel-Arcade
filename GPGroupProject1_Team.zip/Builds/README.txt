Jump Space Bar
A D left right 
Enter Shoot 
right mouse shoot 

Itch page - https://shreyaaaaaa.itch.io/super-citronaut

Repo - https://github.com/Twan-Solo/Pixel-Arcade
